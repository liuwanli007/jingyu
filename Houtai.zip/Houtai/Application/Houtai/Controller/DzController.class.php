<?php
namespace Houtai\Controller;
use Think\Controller;
class DzController extends Controller {

    public function info(){
        $admin = M('admin');
        $list = $admin->where('state=1')->select();
        $this->assign('list',$list);

        $this->display();

    }
     public function back(){
        $admin = M("admin");
        $data['state']='0';
        

        $result =$admin->where('state=1')->field('state')->save($data);
        if($result ) {
                 $this->redirect('index/index');
            }else{
                  $this->redirect('dz/index');
              }
    }
    public function pass(){
        // $admin = M('admin');

        // $list = $admin->where('state=1')->select();
        // $this->assign('list',$list);

        $this->display();

    }
    public function page(){
        $works = M('works');
        $data = M('user  as  a')->join('works  as  b  on b.userid = a.userid and type=1')->select();
        $this->assign('works',$data);

        $this->display();
    }
    public function del(){
        $id = $_POST['id'];
        $obj = M("works");
        if(1){
            
            if($obj->delete($id)){
                $this->success('登录成功,正跳转至系统首页...',0.1);
            }
           
             
        }else{
           
            $this->ajaxReturn($data);
            exit();
        }
    }
    public function adv(){
        $works = M('works');
        $data = M('user  as  a')->join('works  as  b  on b.userid = a.userid and type=2')->select();
        $this->assign('works',$data);

        $this->display();
    }
    public function shipinguanli(){
        $works = M('works');
        $data = M('user  as  a')->join('works  as  b  on b.userid = a.userid and type=3')->select();
        $this->assign('works',$data);

        $this->display();
    }
    public function book(){
        $User = M('User');
        $list = $User->select();
        $this->assign('list',$list);
        $this->display();
    }
}
?>