<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="renderer" content="webkit">
    <title>管理员信息</title>  
    <link rel="stylesheet" href="/Houtai/Public/Houtai/css/pintuer.css">
    <link rel="stylesheet" href="/Houtai/Public/Houtai/css/admin.css">
    <script src="/Houtai/Public/Houtai/js/jquery.js"></script>
    <script src="/Houtai/Public/Houtai/js/pintuer.js"></script>  
</head>
<body>
<div class="panel admin-panel">
<?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="panel-head"><strong><span class="icon-pencil-square-o"></span> 管理员信息</strong></div>
  <div class="body-content">
    <form method="post" class="form-x" action="">
       <div class="form-group" style="width:1500px">
        <div class="label">
          管理员:<?php echo ($vo["nickname"]); ?></br>
          ID：<?php echo ($vo["id"]); ?>
        </div>
       
      </div>      
         
    </form>
  </div><?php endforeach; endif; else: echo "" ;endif; ?>
</div>
</body></html>