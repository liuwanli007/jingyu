<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="renderer" content="webkit">
<title></title>
<link rel="stylesheet" href="/Houtai/Public/Houtai/css/pintuer.css">
<link rel="stylesheet" href="/Houtai/Public/Houtai/css/admin.css">
<script src="/Houtai/Public/Houtai/js/jquery.js"></script>
<script src="/Houtai/Public/Houtai/js/pintuer.js"></script>
</head>
<script type="text/javascript">
        $(document).ready(function(){
            $(".del").children("a").click(function(){
                var Oa=$(this);
                var id=Oa.parent().attr('id');//获取id属性
                if(1){
                    $.post('/Houtai/index.php/Dz/del',{'id':id},function(data){
                            alert('感谢您的支持！');//模拟异步数据加1
                             refresh();
                    },'json'); }  
            });
            function refresh(){
            window.location.reload();//刷新当前页面.
     
    
    }
           
             
        });
    </script>
<body>
<div class="panel admin-panel">
  <div class="panel-head"><strong><span class="icon-pencil-square-o"></span> 段子管理</strong></div>
  <div class="body-content">
    <form method="post" class="form-x" action="">      
     <div class="padding border-bottom">  
   <button type="button"  class="button border-green" href="javascript:void(0)" id="checkall"><span class="icon-check"></span> 全选</button>
          <button type="submit" class="button border-red"><span class="icon-trash-o"></span> 批量删除</button>
  </div>
  <table class="table table-hover text-center">
    <tr>
      <th width="10%">ID</th>
      <th width="20%">段子</th>
      <th width="15%">投稿人</th>
      <th width="20%">日期</th>
      <th width="10%">状态</th>
      <th width="15%">操作</th>
    </tr>
     <?php if(is_array($works)): $i = 0; $__LIST__ = $works;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr >
      <td><input type="checkbox" name="id[]" value="1" /><?php echo ($vo["id"]); ?></td>     
      <td><p><?php echo ($vo["content"]); ?></p></td>     
      <td><?php echo ($vo["nickname"]); ?></td>
      <td>2016-11-21</td>
      <td>未审核</td>
      <td><div class="del" id="<?php echo ($vo["id"]); ?>">
      <a class="button border-main" href="#"><span class="icon-edit"></span> 通过</a>
      <a class="button border-red" href="javascript:void(0)" onclick="return del(1,1)"><span class="icon-trash-o"></span> 删除</a>
      </div></td>
    </tr><?php endforeach; endif; else: echo "" ;endif; ?>
    
     
     <tr>
        <td colspan="8"><div class="pagelist"> <a href="">上一页</a> <span class="current">1</span><a href="">2</a><a href="">3</a><a href="">下一页</a><a href="">尾页</a> </div></td>
      </tr>
  </table>
  <script type="text/javascript">
function del(id,mid){
	if(confirm("您确定要删除吗?")){
	
	}
}
</script>
    </form>
  </div>
</div>
</body></html>