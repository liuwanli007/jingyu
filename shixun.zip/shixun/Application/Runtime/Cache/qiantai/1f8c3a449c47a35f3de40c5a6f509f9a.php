<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>奇葩狗</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/shixun/Public/qiantai/jquery.mobile-1.4.5/jquery.mobile-1.4.5.min.css" />
    <script src="/shixun/Public/qiantai/jQuery.js"></script>
    <script src="/shixun/Public/qiantai/jquery.mobile-1.4.5/jquery.mobile-1.4.5.min.js"></script>
     <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><style type="text/css">
        .ui-icon-img1{
            background-image: url(<?php echo ($vo["head"]); ?>);
            background-size:29px 29px;

        }
        .ui-icon-img2:after{
            background-image: url(/shixun/Public/qiantai/images/8.png);
            background-size:15px 15px;
            border: 0;

        }
        .ui-icon-img3:after{
            background-image: url(/shixun/Public/qiantai/images/9.png);
            background-size:15px 15px;
            border: 0;
        }
        .ui-icon-img4:after{
            background-image: url(/shixun/Public/qiantai/images/10.png);
            background-size:15px 15px;
            border: 0;
        }
        .ui-icon-img5:after{
            background-image: url(/shixun/Public/qiantai/images/11.png);
            background-size:15px 15px;
            border: 0;
        }
        .ul1 li a{

            border: 0px;
            font-family:华文楷体;

        }
        .ul2 li a{
            border: 0px;
        }
        .div1{
            background-color: white;
            margin-top: 2%
        }
        time{
           font-fmaily:微软雅黑;
           font-size:6px;
            color:grey;
            margin-top: 5%;
        }
        .a1 {
            font-size:14px;
            font-family:华文楷体;
            text-decoration:none;
        }
        /*侧边栏*/
        .ui-icon-circle{
            background-image:url(/shixun/Public/qiantai/images/1.png);
        }
        #myPanel a{
            text-decoration:none;
        }
        #myPanel li{
            list-style: none;
        }
        /*他人信息*/
        .guanzhulan p{
            display: inline;
            font-family: "Segoe UI Semibold";
        }
        .tiezi{
            margin-bottom:10px;
            height:auto;
            background-color:white;
        }
        .tiezi div p{
            font-family: "Segoe UI Semibold";
            margin:4px;
        }
        .ui-icon-thumbs:after{background-image:url(/shixun/Public/qiantai/images/2.png)}
        .ui-block-a{
            width: 30%;
        }
        .ui-block-b{
            width: 70%;
        }
        .ui-block-c{
            width:15%;
        }
        .ui-block-d{
            width:85%;
        }
        .ui-block-e{
            width:20%;
            background-color: white;
        }

    </style><?php endforeach; endif; else: echo "" ;endif; ?>
</head>
   
<body>
<div data-role="page" id="page15">
        <!--侧边栏-->
         <div data-role="panel" id="myPanel" data-display="overlay" style="width:200px;background-image: url('/shixun/Public/qiantai/images/2.png');background-size: 100% 150px;background-repeat: no-repeat" >
            <div >
                
                <a href="<?php echo U('qiantai/dz/index13');?>" rel="external" style="">
                    <image src= <?php echo ($vo["head"]); ?> style="height: 60px;width:60px;border-radius: 50%"></image>
                </a><br>
                <div style="margin-top:10px;color:white">
                   
                    <?php echo ($vo["nickname"]); ?><br/>
                  
                </div>
                  </volist>
            </div>
            <p></p>
            <ul data-role="listview" style="margin-top:40px">
                <li data-icon="false"><a href="<?php echo U('qiantai/dz/PersonalData');?>" rel="external">个人资料</a></li>
                <li data-icon="false"><a href="<?php echo U('qiantai/dz/guanzhu');?>" rel="external">关注</a></li>
                <li data-icon="false"><a href="<?php echo U('qiantai/dz/fans');?>" rel="external">粉丝</a></li>
                <li data-icon="false"><a href="#page9" rel="external">收藏</a></li>
            </ul >
                <div data-role="navbar" style="margin-top:150px;widht:100%" >
                    <ul class="ul1">
                        <li><a href="<?php echo U('qiantai/dz/back');?>" rel="external" class="ui-nodisc-icon ui-alt-icon" data-icon="user"  style="text-shadow:none;color:red;">退出登录</a></li>
                        <li><a href="#"   class="ui-nodisc-icon ui-alt-icon" data-icon="back"   style="text-shadow:none;color:black">返回</a></li>
                    </ul>
                </div>
        </div>
         <div data-role="header"  style="background-image: url(/shixun/Public/qiantai/images/2.png)" data-position="fixed">
            <a href="#myPanel" class="ui-nodisc-icon" data-icon="img1" data-iconpos="notext" style="margin-top:6px"></a>
            <div data-role="controlgroup" data-type="horizontal" style="text-align:center">
                 <a href="#" data-role="button" class="ui-btn-active">奇葩圈</a>
                 <a href="<?php echo U('qiantai/dz/index6');?>" data-role="button">生活圈</a>
            </div>
            <a rel="external"  href="<?php echo U('qiantai/dz/set');?>" class="ui-nodisc-icon" data-icon="gear" data-iconpos="notext" style="background-image: url(/shixun/Public/qiantai/images/2.png);margin-top:6px"></a>
            
        </div>
        <div data-role="listview" data-inset="true">
            <li>
                <a href="#page18">评论<span class="ui-li-count">20</span> </a>
            </li>
            <li>
                <a href="#page17">赞<span class="ui-li-count">20</span> </a>
            </li>
            <li>
                <a href="#page16">给我留言<span class="ui-li-count">20</span> </a>
            </li>
        </div>

        <div data-role="footer" data-position="fixed" data-theme="b">
            <div data-role="navbar" >
                <ul class="ul1">
                    <li><a  rel="external" href="<?php echo U('qiantai/dz/index');?>" class="ui-nodisc-icon " data-icon="home"  style="text-shadow:none;color:white">首页</a></li>
                    <li><a  rel="external"  href="<?php echo U('qiantai/dz/contribute');?>"  class="ui-nodisc-icon" data-icon="plus"   style="text-shadow:none;color:white">投稿</a></li>
                    <li><a rel="external" href="#" class="ui-nodisc-icon" data-icon="mail"   style="text-shadow:none;color:yellow;">消息 </a></li>

                </ul>
            </div>


        </div>
    </div>
    </body>
    </html>