<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>奇葩狗</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/shixun/Public/qiantai/jquery.mobile-1.4.5/jquery.mobile-1.4.5.min.css" />
    <script src="/shixun/Public/qiantai/jQuery.js"></script>
    <script src="/shixun/Public/qiantai/jquery.mobile-1.4.5/jquery.mobile-1.4.5.min.js"></script>

</head>
<body>
 <div data-role="header"  style="background-image: url(/shixun/Public/qiantai/images/2.png)" data-position="fixed">
            <a href="#page1" class="ui-nodisc-icon " data-icon="carat-l" style="background-image:url(/shixun/Public/qiantai/images/2.png);border:0px;margin-top: 20px;"></a>
            <div data-role="controlgroup" data-type="horizontal" style="text-align:center;color:white;font-family:微软雅黑">
               <p>投稿</p>
            </div>
        </div>


  <?php if(is_array($text)): $i = 0; $__LIST__ = $text;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div data-role="fieldcontain">
    <form id="lg-form" action="<?php echo U('qiantai/dz/tou');?>"  method="post" name="lg-form"  enctype="multipart/form-data" data-ajax="false">
         <textarea cols="10" rows="1" name="userid" id="textarea" placeholder="请输入内容..." style="display:none"><?php echo ($vo["userid"]); ?></textarea>
        <textarea cols="40" rows="8" name="content" id="textarea" placeholder="请输入内容..."></textarea>
        <div data-role="controlgroup" data-type="horizontal" style="text-align: center">
            <input id="sub" type="submit" value="发表">
        </div>
        </form>
</div><?php endforeach; endif; else: echo "" ;endif; ?>


</body>
</html>