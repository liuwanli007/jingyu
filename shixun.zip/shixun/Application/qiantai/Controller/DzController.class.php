<?php
namespace qiantai\Controller;
use Think\Controller;
class DzController extends Controller {

    
    public function index(){
    	// $works = M('works');
    
    	// $data = M('user  as  a')->join('works  as  b  on b.userid = a.userid ')->select();
    	// $this->assign('works',$data);

    	$User = M('User');
		$list = $User->where('state=1')->select();
		$this->assign('list',$list);
		//获取段子
		$works = M('works');
    	$text = M('user  as  a')->join('works  as  b  on b.userid = a.userid and type=1 and  good>=100')->select();
    	$this->assign('text',$text);
    	//获取视频
    	$vids = M('works');
    	$vid = M('user  as  a')->join('works  as  b  on b.userid = a.userid and type=3 and good>=100')->select();
    	$this->assign('vid',$vid);
		//获取图片
    	$imgs = M('works');
    	$img = M('user  as  a')->join('works  as  b  on b.userid = a.userid and type=2 and good>=100')->select();
    	$this->assign('img',$img);

    	$this->display();
    }
    public function back(){
        $user = M("user");
        $data['state']='0';
        

        $result =$user->where('state=1')->field('state')->save($data);
        if($result ) {
                 $this->redirect('index/index');
            }else{
                  $this->redirect('dz/index');
              }
    }
     public function index2(){
     	$User = M('User');
		$list = $User->where('state=1')->select();
		$this->assign('list',$list);

    	$works = M('works');
    	// $data = $works->select();
    	// $this->assign('works',$data);
    	$data = M('user  as  a')->join('works  as  b  on b.userid = a.userid and type=1')->select();
    	$this->assign('works',$data);
    	$this->display();
    }

    public function index3(){
    	$User = M('User');
		$list = $User->where('state=1')->select();
		$this->assign('list',$list);

    	$works = M('works');
    	$data = M('user  as  a')->join('works  as  b  on b.userid = a.userid and type=3')->select();
    	$this->assign('works',$data);
    	$this->display();
    }
    public function index4(){
    	$User = M('User');
		$list = $User->where('state=1')->select();
		$this->assign('list',$list);
		

    	$works = M('works');
    	// $data = $works->select();
    	// $this->assign('works',$data);
    	$data = M('user  as  a')->join('works  as  b  on b.userid = a.userid and type=2')->select();
    	$this->assign('works',$data);
    	$this->display();
    }
    public function index13(){
    	$User = M('User');
		$list = $User->where('state=1')->select();
		$this->assign('list',$list);
		//获取段子
		$works = M('works');
    	$text = M('user  as  a')->join('works  as  b  on b.userid = a.userid and type=1 and a.state=1')->select();
    	$this->assign('text',$text);
    	//获取视频
    	$vids = M('works');
    	$vid = M('user  as  a')->join('works  as  b  on b.userid = a.userid and type=3 and a.state=1')->select();
    	$this->assign('vid',$vid);
		//获取图片
    	$imgs = M('works');
    	$img = M('user  as  a')->join('works  as  b  on b.userid = a.userid and type=2 and a.state=1')->select();
    	$this->assign('img',$img);
		
    	$this->display();
    }
    public function addgood(){
	   	$data['id']=isset($_POST['id'])?intval(trim($_POST['id'])):1;
        $obj = M("works");
        if(1){
           	$obj->where($data['id'])->setInc('good',1);
            $this->ajaxReturn($data);
             
            exit();
        }else{
            $this->ajaxReturn($data);
            exit();
        }

	}
	public function addbad(){
	    $data['id']=isset($_POST['id'])?intval(trim($_POST['id'])):0;
        $obj = M("works");
        if(1){
           	$obj->where($data['id'])->setInc('bad',1);
            $this->ajaxReturn($data);
             
            exit();
        }else{
           
            $this->ajaxReturn($data);
            exit();
        }
	}
    public function gz(){
        $data['id']=isset($_POST['id'])?intval(trim($_POST['id'])):0;
        $works=M('works');
        $obj=$work->where($data['id'])->select();
        if(1){
            
            $this->ajaxReturn($data);
            exit();
        }else{
           
            $this->ajaxReturn($data);
            exit();
        }

    }
	public function index6(){
		$User = M('User');
		$list = $User->where('state=1')->select();
		$this->assign('list',$list);

		$works = M('trends');
    	$text = M('user  as  a')->join('trends  as  b  on b.userid = a.userid')->select();
    	$this->assign('text',$text);

		$this->display();
	}
	public function index7(){
		$User = M('User');
		$list = $User->where('state=1')->select();
		$this->assign('list',$list);

		
		$works = M('trends');
    	$text = M('user  as  a')->join('trends  as  b  on b.userid = a.userid')->join('focuslist as c on c.BeFollowed_ID = b.id')->select();
    	$this->assign('text',$text);
		
		$this->display();
	}
	public function index8(){
		$User = M('User');
		$list = $User->where('state=1')->select();
		$this->assign('list',$list);
		
		$works = M('works');
    	$text = M('user  as  a')->join('trends  as  b  on b.userid = a.userid and a.state=1')->select();
    	$this->assign('text',$text);

		$this->display();
	}
    public function PersonalData(){

        $user = M('user');
        $data = $user->where('state=1')->select();
        $this->assign('list',$data);

        $this->display();
    }
     public function tougao(){
            $user = M('user');
            $list = $user->where('state=1')->select();            
            $this->assign('text',$list);
            $this->display();
         }
    public function tou(){

        // $data['content'] = $_POST['content'];
        // $data['userid']=1;
        // $works = M('works');
        // $works->create();
        $works = M("works"); // 实例化User对象

        if($works->create()){
            $result = $works->add(); // 写入数据到数据库 
            if($result){
                // 如果主键是自动增长型 成功后返回值就是最新插入的值
                $insertId = $result;
                $this->redirect('dz/index');
            }
        }
    }
    public function guanzhu(){
        $user = M('user');
        $text = M('user  as  a')->join('focuslist  as  b  on b.BeFollowed_ID = a.userid and a.state!=1')->select();
        $this->assign('text',$text);

        $this->display();
    }
    public function fans(){
        $user = M('user');
        $text = M('user  as  a')->join('focuslist  as  b  on b.Follower_ID= a.userid and a.state!=1')->select();
        $this->assign('text',$text);

        $this->display();
    }
    public function xiaoxi(){
        $User = M('User');
        $list = $User->where('state=1')->select();
        $this->assign('list',$list);
        $this->display();
    }
    public function pinglun(){
        
        if(1){
           
            $works = M('works');
            $text = M('user  as  a')->where('id=1')->join('works  as  b  on b.userid = a.userid')->select();
            $this->assign('list',$text);

            $this->display();
             
        }else{
            exit();
        }
    }
}
?>